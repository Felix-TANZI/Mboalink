# Portail Captif Wi-Fi — Hilton Brazzaville Les Tours Jumelles

Portail captif d'authentification Wi-Fi pour hôtel, développé avec **Next.js 16** et **PostgreSQL**. Permet aux clients de se connecter au réseau Wi-Fi en saisissant leur nom de famille et leur numéro de chambre.

---

## Stack technique

| Composant   | Technologie          |
|-------------|----------------------|
| Frontend    | Next.js 16 (App Router) + Tailwind CSS v4 |
| Backend     | Next.js API Routes   |
| Base de données | PostgreSQL 16   |
| Conteneurisation | Docker + Docker Compose |

---

## Prérequis

- [Docker](https://docs.docker.com/get-docker/) ≥ 24
- [Docker Compose](https://docs.docker.com/compose/) ≥ 2.20

---

## Lancement rapide (Docker)

```bash
# 1. Cloner / accéder au dossier
cd radius

# 2. Lancer les services (PostgreSQL + Next.js)
docker compose up --build

# 3. Ouvrir le portail dans votre navigateur
# http://localhost:3000
```

> La base de données est automatiquement initialisée avec les 5 clients au premier démarrage.

Pour arrêter :
```bash
docker compose down
```

Pour tout supprimer (données incluses) :
```bash
docker compose down -v
```

---

## Développement local (sans Docker)

```bash
# 1. Installer les dépendances
npm install

# 2. Configurer les variables d'environnement
cp .env.example .env.local
# Éditer .env.local avec vos paramètres PostgreSQL

# 3. Initialiser la base de données
psql -U postgres -d radius_hotel -f init.sql

# 4. Lancer le serveur de développement
npm run dev
# http://localhost:3000
```

---

## Clients de test

| # | Prénom      | Nom de famille | Chambre |
|---|-------------|----------------|---------|
| 1 | Jean-Pierre | DUPONT         | 101     |
| 2 | Marie       | MARTIN         | 201     |
| 3 | Pierre      | BERNARD        | 301     |
| 4 | Sophie      | THOMAS         | 401     |
| 5 | Lucas       | PETIT          | 501     |

> La recherche est insensible à la casse : `dupont` = `DUPONT` = `Dupont`.

---

## Structure du projet

```
radius/
├── app/
│   ├── layout.tsx              # Layout racine
│   ├── globals.css             # Tailwind CSS
│   ├── page.tsx                # Page de login (portail captif)
│   ├── success/
│   │   └── page.tsx            # Page de confirmation de connexion
│   └── api/
│       └── auth/
│           └── route.ts        # API POST /api/auth
├── lib/
│   └── db.ts                   # Pool de connexions PostgreSQL
├── init.sql                    # Script d'initialisation BD (clients + tables)
├── Dockerfile                  # Build multi-stage Next.js
├── docker-compose.yml          # Orchestration Next.js + PostgreSQL
├── .env.example                # Variables d'environnement (modèle)
├── next.config.ts
├── package.json
└── README.md
```

---

## Variables d'environnement

| Variable           | Valeur par défaut | Description              |
|--------------------|-------------------|--------------------------|
| `POSTGRES_HOST`    | `localhost`       | Hôte PostgreSQL          |
| `POSTGRES_PORT`    | `5432`            | Port PostgreSQL          |
| `POSTGRES_DB`      | `radius_hotel`    | Nom de la base           |
| `POSTGRES_USER`    | `postgres`        | Utilisateur              |
| `POSTGRES_PASSWORD`| `postgres`        | Mot de passe             |

---

## Flux d'authentification

```
Client browser
    │
    │  POST /api/auth { nomFamille, numeroChambre }
    ▼
Next.js API Route
    │
    │  SELECT * FROM clients WHERE UPPER(nom_famille) = UPPER($1) AND numero_chambre = $2
    ▼
PostgreSQL
    │
    ├─ Trouvé → INSERT INTO connexions (log) → 200 { success: true, prenom, ... }
    └─ Introuvable → 401 { success: false, message: "..." }
    │
    ▼
Client browser → redirect /success  (ou affiche erreur)
```

---

## Ports exposés

| Service    | Port local | Description        |
|------------|------------|--------------------|
| Next.js    | `3000`     | Portail captif     |
| PostgreSQL | `5432`     | Base de données    |
