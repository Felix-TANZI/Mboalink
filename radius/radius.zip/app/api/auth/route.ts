import { NextRequest, NextResponse } from "next/server";
import pool from "@/lib/db";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { nomFamille, numeroChambre } = body;

    if (!nomFamille || !numeroChambre) {
      return NextResponse.json(
        { success: false, message: "Nom de famille et numéro de chambre requis." },
        { status: 400 }
      );
    }

    const result = await pool.query(
      `SELECT id, prenom, nom_famille, numero_chambre
       FROM clients
       WHERE UPPER(nom_famille) = UPPER($1)
         AND numero_chambre = $2`,
      [nomFamille.trim(), numeroChambre.trim()]
    );

    if (result.rowCount === 0) {
      return NextResponse.json(
        { success: false, message: "Nom de famille ou numéro de chambre incorrect." },
        { status: 401 }
      );
    }

    const client = result.rows[0];

    // Log de la connexion
    await pool.query(
      `INSERT INTO connexions (client_id, ip_address) VALUES ($1, $2)`,
      [client.id, req.headers.get("x-forwarded-for") ?? req.headers.get("x-real-ip") ?? "unknown"]
    );

    return NextResponse.json({
      success: true,
      prenom: client.prenom,
      nomFamille: client.nom_famille,
      numeroChambre: client.numero_chambre,
    });
  } catch (err) {
    console.error("[AUTH ERROR]", err);
    return NextResponse.json(
      { success: false, message: "Erreur serveur. Veuillez réessayer." },
      { status: 500 }
    );
  }
}
