-- ============================================================
--  Portail Captif Wi-Fi – Hilton Brazzaville Les Tours Jumelles
--  Initialisation de la base de données
-- ============================================================

-- Table des clients (associée aux chambres)
CREATE TABLE IF NOT EXISTS clients (
    id             SERIAL PRIMARY KEY,
    prenom         VARCHAR(100) NOT NULL,
    nom_famille    VARCHAR(100) NOT NULL,
    numero_chambre VARCHAR(10)  NOT NULL UNIQUE,
    email          VARCHAR(150),
    telephone      VARCHAR(20),
    date_arrivee   DATE         NOT NULL DEFAULT CURRENT_DATE,
    date_depart    DATE,
    actif          BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at     TIMESTAMP    NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMP    NOT NULL DEFAULT NOW()
);

-- Table des connexions Wi-Fi (historique)
CREATE TABLE IF NOT EXISTS connexions (
    id          SERIAL PRIMARY KEY,
    client_id   INTEGER      NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    ip_address  VARCHAR(45),
    connected_at TIMESTAMP   NOT NULL DEFAULT NOW()
);

-- Index pour accélérer les recherches par nom et chambre
CREATE INDEX IF NOT EXISTS idx_clients_nom_famille    ON clients (UPPER(nom_famille));
CREATE INDEX IF NOT EXISTS idx_clients_numero_chambre ON clients (numero_chambre);
CREATE INDEX IF NOT EXISTS idx_connexions_client_id   ON connexions (client_id);

-- ============================================================
--  Données : 5 clients / 5 chambres
-- ============================================================

INSERT INTO clients (prenom, nom_famille, numero_chambre, email, telephone, date_arrivee, date_depart) VALUES
    ('Client 1', 'client1', '101', 'client1@hilton.cg', '+242 06 100 0001', CURRENT_DATE, CURRENT_DATE + INTERVAL '5 days'),
    ('Client 2', 'client2', '201', 'client2@hilton.cg', '+242 06 200 0002', CURRENT_DATE, CURRENT_DATE + INTERVAL '3 days'),
    ('Client 3', 'client3', '301', 'client3@hilton.cg', '+242 06 300 0003', CURRENT_DATE, CURRENT_DATE + INTERVAL '7 days'),
    ('Client 4', 'client4', '401', 'client4@hilton.cg', '+242 06 400 0004', CURRENT_DATE, CURRENT_DATE + INTERVAL '2 days'),
    ('Client 5', 'client5', '501', 'client5@hilton.cg', '+242 06 500 0005', CURRENT_DATE, CURRENT_DATE + INTERVAL '4 days')
ON CONFLICT (numero_chambre) DO NOTHING;
